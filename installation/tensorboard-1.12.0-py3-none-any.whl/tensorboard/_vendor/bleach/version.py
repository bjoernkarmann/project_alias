# -*- coding: utf-8 -*-

from __future__ import unicode_literals

VERSION = (1, 5, 0)
__version__ = '.'.join([str(n) for n in VERSION])
